public class BinarySearch {
    public static int binarySearch(int[] arr, int n){
        int l = 0; int r = arr.length-1; int m = Math.floorDiv(r,2);
        while (l <= r){
            if (arr[m] == n){return m;}
            if (n > arr[m]){l = m + 1;}
            else {r = m - 1;}
            m = l + Math.floorDiv(r - l, 2);
        }
        return -1;
    }
}